
  # CRM

  This is a code bundle for CRM. The original project is available at https://www.figma.com/design/TYApQNgzfuZfTdqmKJt1vD/CRM.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  